/*
  MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QFile>
#include <QTextStream>

#include "dialogoptions.h"
#include "ui_dialogoptions.h"

DialogOptions::DialogOptions( QString my_fileOptions, QWidget *parent ) :
    QDialog(parent),
    ui(new Ui::DialogOptions)
{
    ui->setupUi(this);

    setWindowTitle( QCoreApplication::applicationName() );

    QString fontString, fontSize, voice;
    fileOptions = my_fileOptions + "/Options.par";
    QFile fileRead( fileOptions );
    if ( fileRead.open( QIODevice::ReadOnly | QIODevice::Text ) ) {
        QTextStream in( &fileRead );
        fontString = in.readLine();
        fontSize = in.readLine();
        voice = in.readLine();
    } else {
        fontString = "Arial";
        fontSize = "32";
        voice = "true";
    }
    fileRead.close();

    ui->fontComboBoxFont->setCurrentFont( fontString );

    for ( int tam = 18; tam < 36; tam = tam + 2 )
       ui->comboBoxFontSize->addItem( QString::number( tam ) );
    ui->comboBoxFontSize->setCurrentText( fontSize );

    if ( voice == "true" )
        ui->checkBoxVoice->setChecked( true );
    else
        ui->checkBoxVoice->setChecked( false );
}

DialogOptions::~DialogOptions()
{
    delete ui;
}

void DialogOptions::on_pushButtonOk_clicked()
{
    QFile fileWrite( fileOptions );
    if ( fileWrite.open( QIODevice::WriteOnly | QIODevice::Text ) ) {
        QTextStream out( &fileWrite );
        out << ui->fontComboBoxFont->currentText() << "\n";
        out << ui->comboBoxFontSize->currentText() << "\n";
        if( ui->checkBoxVoice->isChecked() )
            out << "true" << "\n";
        else
            out << "false" << "\n";
    }
    fileWrite.close();

    on_pushButtonCancel_clicked();
}

void DialogOptions::on_pushButtonCancel_clicked()
{
    close();
}
