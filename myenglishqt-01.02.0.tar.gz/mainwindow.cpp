﻿/*
  MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QFileDialog>
#include <QStandardPaths>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDir>
#include <QFileInfo>
#include <QInputDialog>
#include <QDesktopServices>
#include <QTextStream>
#include <QDateTime>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialogedittest.h"
#include "dialogflashcards.h"
#include "dialogexam.h"
#include "dialogoptions.h"

#define NUM_VERSION 1.02

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle(QCoreApplication::applicationName());
    setWindowFlags(Qt::Window);

    dirTeses = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/MyEnglishQt/";

    //Si no existe la carpeta test en la carpeta documentos, se crea.
    if ( !QDir( dirTeses ).exists() )
        QDir( dirTeses ).mkdir( dirTeses );

    //Si no existe el archivo de la opciones de fuente y tamaño de la fuente, se crea.
    QString fileOptions = dirTeses + "/Options.par";
    if ( !QFile( fileOptions ).exists() ){
        QFile fileWrite( fileOptions );
        if ( fileWrite.open( QIODevice::WriteOnly | QIODevice::Text ) ) {
            QTextStream out( &fileWrite );
            out << "Arial" << "\n";
            out << "32" << "\n";
            out << "true" << "\n";
        }
        fileWrite.close();
    }

    funFontAndFontSize();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonFlashCards_clicked()
{
    QString fileTest = QFileDialog::getOpenFileName( this, tr( "Examen" ), dirTeses, "Files (*.cid)" );
    if(fileTest.isEmpty())
        return;


    QString fileDay = dirTeses + "/flashcardsforday.par";
    QFileInfo info( fileDay );
    //Si cierto, el archivo ha sido accedido hoy, no es la primera vez que se viene a FlashCards.
    if( info.lastRead().date() == QDate::currentDate() ) {

        //Se comprueba que no se haya hecho ya el FlashCards del Test.
        QFile fileReadDay( fileDay );
        if ( fileReadDay.open( QIODevice::ReadOnly | QIODevice::Text ) ) {

            QTextStream inDay( &fileReadDay );
            bool testHecho = false;
            while (!inDay.atEnd())
            {
                //Si ya hemos hecho el Test hoy, se indica para salir sin más de FlashCards.
                if( fileTest == inDay.readLine() )
                    testHecho = true;
            }
            fileReadDay.close();

            if( testHecho ) {

                QMessageBox::warning( this, QCoreApplication::applicationName(), tr("Sólo se puede hacer un FlashCards diario de un mismo Test") );
                return;

            //Si el Test no se ha hecho hoy, se guarda, se añade, en el archivo para no volverlo hacer hoy.
            } else {

                QFile fileWriteDay( fileDay );
                if ( fileWriteDay.open( QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text ) ) {
                    QTextStream outDay( &fileWriteDay );
                    outDay << fileTest << "\n";
                }
                fileWriteDay.close();

            }
        }

    //Si no se  ha accedido al archivo hoy, es que es la primera vez. Se borra el viejo y crea un archivo nuevo para guardar los Test hecho hoy.
    } else {

        QFile( fileDay ).remove();

        QFile fileWriteDay( fileDay );
        if ( fileWriteDay.open( QIODevice::WriteOnly | QIODevice::Text ) ) {
            QTextStream outDay( &fileWriteDay );
            outDay << fileTest << "\n";
        }
        fileWriteDay.close();
    }

    DialogFlashCards dfc ( fileTest, font, fontSize, voice );
    dfc.exec();
}

void MainWindow::on_pushButtonEdit_clicked()
{
    QString fileTest = QFileDialog::getOpenFileName( this, tr( "Editar" ), dirTeses, "Files (*.cid)" );
    if(fileTest.isEmpty())
        return;

    DialogEditTest det( fileTest );
    det.exec();
}

void MainWindow::on_pushButtonNew_clicked()
{
    bool ok;
    QString text = QInputDialog::getText( this, QCoreApplication::applicationName(),
                                          tr("Introduzca el título:"),
                                          QLineEdit::Normal, "", &ok);
    if ( ok && !text.isEmpty() ){

        QString fileBDTestG = dirTeses + text + ".cid";

        if( QFile( fileBDTestG ).exists() )
            QMessageBox::warning( this, QCoreApplication::applicationName(), tr("El título introducido ya existe. Introduzca otro.") );
        else {
            baseTestG.removeDatabase("my_conection_name");
            baseTestG = QSqlDatabase::addDatabase("QSQLITE", "my_conection_name");
            baseTestG.setDatabaseName( fileBDTestG );
            if (!baseTestG.open()){
                QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos"));
                baseTestG.close();
                return;
            }

            QSqlQuery queryG(baseTestG);
            queryG.exec("CREATE TABLE frases ("
                       "ind  INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,"
                       "ingles VARCHAR(200),"
                       "espanol VARCHAR(200),"
                       "cajas INTEGER )"
                       );
            //Se crea una base de datos con 1 elemento
            queryG.prepare("INSERT INTO frases (ind, ingles, espanol, cajas) "
                         "VALUES (?, ?, ?, ?)");
            queryG.addBindValue(1);
            queryG.addBindValue("");
            queryG.addBindValue("");
            queryG.addBindValue(1);
            queryG.exec();

            baseTestG.close();

            DialogEditTest det( fileBDTestG );
            det.exec();
        }
    }
}

void MainWindow::on_pushButtonAbout_clicked()
{
    QString msg = "MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid\n\n"

            "Version: " + QString::number( NUM_VERSION ) + "\n\n"

            "Email: linuxcqt@gmail.com\n\n"

            "This program is free software: you can redistribute it and/or modify"
            "it under the terms of the GNU General Public License as published by"
            "the Free Software Foundation, either version 3 of the License, or"
            "(at your option) any later version.\n\n"

            "This program is distributed in the hope that it will be useful,"
            "but WITHOUT ANY WARRANTY; without even the implied warranty of"
            "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
            "GNU General Public License for more details.\n\n"

            "You should have received a copy of the GNU General Public License"
            "along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\n";

    QMessageBox::information(this, QCoreApplication::applicationName(), msg);

    //Mostramos el archivo README sito en el directorio de la aplicación con información sobre el programa.
    QDesktopServices::openUrl( QCoreApplication::applicationDirPath() + "/README");
}

void MainWindow::on_pushButtonExam_clicked()
{
    QString fileTest = QFileDialog::getOpenFileName( this, tr( "Examen" ), dirTeses, "Files (*.cid)" );
    if(fileTest.isEmpty())
        return;

    //Comprobar que la base de datos no esté vacía
    QSqlDatabase base;
    base.removeDatabase( "myConnectionName" );
    base = QSqlDatabase::addDatabase( "QSQLITE", "myConnectionName" );
    base.setDatabaseName( fileTest );

    if( !base.open() ){
        QMessageBox::warning( this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos") );
        base.close();
        return;
    }

    QSqlQuery query( "SELECT * FROM frases", base );
    int numRecords = 0;
    while( query.next() )
        numRecords++;

    if ( numRecords < 7 ){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("El Test debe de tener al menos 7 preguntas"));
        return;
    }

    base.close();

    DialogExam miDialogExam( fileTest, font, fontSize, voice );
    miDialogExam.exec();
}

void MainWindow::on_pushButtonOptions_clicked()
{
    DialogOptions mDOptions( dirTeses );
    mDOptions.exec();

    funFontAndFontSize();
}

void MainWindow::funFontAndFontSize()
{
    QString fileOptions = dirTeses + "/Options.par";
    QFile fileRead( fileOptions );
    if ( fileRead.open( QIODevice::ReadOnly | QIODevice::Text ) ) {
        QTextStream in( &fileRead );
        font = in.readLine();
        fontSize = in.readLine();
        voice = in.readLine();
    } else {
        font = "Arial";
        fontSize = "32";
        voice = "true";
    }
    fileRead.close();
}
