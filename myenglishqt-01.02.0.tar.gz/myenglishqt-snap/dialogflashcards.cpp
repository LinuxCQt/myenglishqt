/*
  MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QFile>
#include <QMessageBox>
#include <QTextStream>

#include "dialogflashcards.h"
#include "ui_dialogflashcards.h"

DialogFlashCards::DialogFlashCards( QString a_nameTest, QString my_font, QString my_fontSize, QString my_voice, QWidget *parent ) :
    QDialog(parent),
    ui(new Ui::DialogFlashCards)
{
    ui->setupUi(this);
    setWindowTitle(QCoreApplication::applicationName());
    setWindowFlags(Qt::Window);
    //showMaximized();

    setWindowIcon(QIcon(QCoreApplication::applicationDirPath() + "imagen.ico"));

    voice = my_voice;

    nameTest = a_nameTest;
    font = my_font;
    fontSize = my_fontSize;
    QFont f( font, fontSize.toInt() );
    ui->textEdit->setFont( f );

    base.removeDatabase( "my_connection_name" );
    base = QSqlDatabase::addDatabase( "QSQLITE", "my_connection_name" );
    base.setDatabaseName( nameTest );

    if( !base.open() ){
        QMessageBox::warning( this, QCoreApplication::applicationName(), tr( "Error en la conexión con la base de datos" ) );
        base.close();
        return;
    }

    query = new QSqlQuery( "SELECT * FROM frases WHERE cajas < 5", base );
    int numRecords = 0;
    while( query->next() )
        numRecords++;

    query->seek( 0 );

    if ( voice == "true" ) {
        speech = new QTextToSpeech( this );
        speech->setLocale( QLocale( QLocale::English, QLocale::LatinScript, QLocale::UnitedStates ) );
        speech->setRate( 0.0 );
        speech->setPitch( 1.0 );
        speech->setVolume( 1.0 );
    }

    ui->pushButtonFrontBack->setText( tr( "Cara" ) );
    on_pushButtonFrontBack_clicked();
}

DialogFlashCards::~DialogFlashCards()
{
    if ( voice == "true" ) {
        speech->stop();
        delete speech;
    }
    delete ui;
}

void DialogFlashCards::funNext()
{
    if( query->next() ) {
        ui->pushButtonFrontBack->setText( tr( "Cara" ) );
        on_pushButtonFrontBack_clicked();
    } else {
        QMessageBox::information(this, QCoreApplication::applicationName(), tr("Hemos llegado al final"));
        close();
    }
}

void DialogFlashCards::funCenterText( QString cadena )
{
    ui->textEdit->clear();

    QTextCursor cursor = ui->textEdit->textCursor();
    QTextBlockFormat textBlockFormat = cursor.blockFormat();
    textBlockFormat.setAlignment( Qt::AlignCenter );
    cursor.mergeBlockFormat( textBlockFormat );
    ui->textEdit->setTextCursor( cursor );

    ui->textEdit->append( "\n" );
    ui->textEdit->append( cadena );
}

void DialogFlashCards::on_pushButtonFrontBack_clicked()
{
    QString ingles, espanol;
    ingles = query->value(1).toString();
    espanol = query->value(2).toString();

    if ( ui->pushButtonFrontBack->text() == tr( "Cara" ) ){

        ui->pushButtonFrontBack->setText( tr( "Reverso" ) );
        //Se pone únicamente el texto en inglés
        funCenterText( ingles );

        if ( voice == "true" )
            speech->say( ingles );

    } else {

        ui->pushButtonFrontBack->setText( tr( "Cara" ) );
        funCenterText( espanol );

    }
    ui->pushButtonFrontBack->setDefault( true );
    ui->pushButtonFrontBack->setFocus();
}

void DialogFlashCards::closeEvent ( QCloseEvent * )
{
    base.close();
}

void DialogFlashCards::funGuardarResultadoEnCajas( bool respuesta )
{
    int numCaja = query->value(3).toInt();

    //Si respuesta es correcta se avanza una caja.
    if( respuesta )
        numCaja++;

    //Si respuesta es incorrecta, se vuelve a la caja número 1.
    else
        numCaja = 1;

    QSqlQuery queryUpdate( base );
    queryUpdate.prepare( "UPDATE frases SET cajas = ? WHERE ind = ?");
    queryUpdate.addBindValue( numCaja );
    queryUpdate.addBindValue( query->value(0).toInt() );
    queryUpdate.exec();
}

void DialogFlashCards::on_pushButtonIDoNotKnow_clicked()
{
    funGuardarResultadoEnCajas( false );
    funNext();
}

void DialogFlashCards::on_pushButtonIKnow_clicked()
{
    funGuardarResultadoEnCajas( true );
    funNext();
}
