/*
    MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <QMessageBox>
#include <QFile>
#include <QTime>
#include <QMouseEvent>
#include <QRandomGenerator64>

#include "dialogexam.h"
#include "ui_dialogexam.h"

DialogExam::DialogExam( QString a_nameTest, QString my_font, QString my_fontSize, QString my_voice, QWidget *parent ) :
    QDialog(parent),
    ui(new Ui::DialogExam)
{
    ui->setupUi(this);

    setWindowTitle(QCoreApplication::applicationName());
    setWindowFlags(Qt::Window);
    //showMaximized();

    setWindowIcon(QIcon(QCoreApplication::applicationDirPath() + "imagen.ico"));

    voice = my_voice;

    nameTest = a_nameTest;
    font = my_font;
    fontSize = my_fontSize;

    QFont f( font, fontSize.toInt() );
    ui->textEditQuestion->setFont( f );
    ui->textEditA->setFont( f );
    ui->textEditB->setFont( f );
    ui->textEditC->setFont( f );
    ui->textEditD->setFont( f );

    numPreguntas = 0;
    numFalladas = 0;

    base.removeDatabase("my_connection_name");
    base = QSqlDatabase::addDatabase("QSQLITE", "my_connection_name");
    base.setDatabaseName(nameTest);

    if(!base.open()){
        QMessageBox::warning(this, QCoreApplication::applicationName(), tr("Error en la conexión con la base de datos"));
        base.close();
        return;
    }

    query = new QSqlQuery("SELECT * FROM frases", base);
    rowCount = 0;
    while( query->next() ) {
        rowCount++;
        listQuestions << query->value(1).toString();
        listAnswers << query->value(2).toString();
    }

    query->seek( 0 );

    if ( voice == "true" ) {
        speech = new QTextToSpeech( this );
        speech->setLocale( QLocale( QLocale::English, QLocale::LatinScript, QLocale::UnitedStates ) );
        speech->setRate( 0.0 );
        speech->setPitch( 1.0 );
        speech->setVolume( 1.0 );
    }

    on_pushButtonNext_clicked();
}

DialogExam::~DialogExam()
{
    if ( voice == "true" ) {
        speech->stop();
        delete speech;
    }
    delete ui;
}

void DialogExam::closeEvent ( QCloseEvent * )
{
    if( numPreguntas != 0 ){
        int correctas = numPreguntas - numFalladas;
        int porcentaje = ( correctas * 100 ) / numPreguntas;

        QString cad = "Number of questions asked: " + QString::number( numPreguntas ) + "\n"
                      "Number of successful questions: " + QString::number( correctas ) + "\n"
                      "Number of failed questions: "  + QString::number( numFalladas ) + "\n"
                      "Hit percentage: " + QString::number( porcentaje ) + "%";
        QMessageBox::information(this, "Exam", cad);
    }
}

bool DialogExam::checkrep(int n, int num[])
{
    for( int i = 0; i < 4; i++ )
        //No se puede repetir el número generado o el de la respuesta correcta
        if( n == num[ i ] )
            return true;
    return false;
}

void DialogExam::funCheck()
{
    if( ui->pushButtonNext->text() == tr( "Siguiente" ) ) {
        on_pushButtonNext_clicked();
        return;
    }

    ui->pushButtonNext->setText( tr( "Siguiente" ) );
    ui->radioButtonA->setEnabled( false );
    ui->radioButtonB->setEnabled( false );
    ui->radioButtonC->setEnabled( false );
    ui->radioButtonD->setEnabled( false );

    ui->textEditQuestion->setStyleSheet( "background-color: green; color: white" );

    if( posCorrecta == 0 && posRespuestaUsuario == 0 )
        ui->textEditA->setStyleSheet( "background-color: green; color: white" );
    else if( posCorrecta == 1 && posRespuestaUsuario == 1 )
        ui->textEditB->setStyleSheet( "background-color: green; color: white" );
    else if( posCorrecta == 2 && posRespuestaUsuario == 2 )
        ui->textEditC->setStyleSheet( "background-color: green; color: white" );
    else if( posCorrecta == 3 && posRespuestaUsuario == 3 )
        ui->textEditD->setStyleSheet( "background-color: green; color: white" );
    else {
        switch ( posRespuestaUsuario ) {
        case 0:
            ui->textEditA->setStyleSheet( "background-color: red; color: white" );
            break;
        case 1:
            ui->textEditB->setStyleSheet( "background-color: red; color: white" );
            break;
        case 2:
            ui->textEditC->setStyleSheet( "background-color: red; color: white" );
            break;
        case 3:
            ui->textEditD->setStyleSheet( "background-color: red; color: white" );
            break;
        }

        switch ( posCorrecta ) {
        case 0:
            ui->textEditA->setStyleSheet( "background-color: green; color: white" );
            break;
        case 1:
            ui->textEditB->setStyleSheet( "background-color: green; color: white" );
            break;
        case 2:
            ui->textEditC->setStyleSheet( "background-color: green; color: white" );
            break;
        case 3:
            ui->textEditD->setStyleSheet( "background-color: green; color: white" );
            break;
        }
        numFalladas++;
    }

    numPreguntas++;
    posCorrecta = 0;
    posRespuestaUsuario = 0;
}

void DialogExam::funShowFicha()
{
    ui->radioButtonA->setChecked( true );

    ui->textEditQuestion->setStyleSheet( "background-color: white; color: black" );

    ui->textEditA->setStyleSheet( "background-color: white; color: black" );
    ui->textEditB->setStyleSheet( "background-color: white; color: black" );
    ui->textEditC->setStyleSheet( "background-color: white; color: black" );
    ui->textEditD->setStyleSheet( "background-color: white; color: black" );

    QStringList lista;
    if ( numPreguntas >= 0 && ( numPreguntas + 3 ) < listAnswers.size() ) {

        lista << listAnswers.at( numPreguntas );
        lista << listAnswers.at( numPreguntas + 1 );
        lista << listAnswers.at( numPreguntas + 2 );
        lista << listAnswers.at( numPreguntas + 3 );

    } else if ( numPreguntas - 3 >= 0 ) {

        lista << listAnswers.at( numPreguntas );
        lista << listAnswers.at( numPreguntas - 1 );
        lista << listAnswers.at( numPreguntas - 2 );
        lista << listAnswers.at( numPreguntas - 3 );

    }

    //Generamos los númeroa aleatorios de las respuestas
    int n, num[4];
    for( int i = 0; i < 4; i++ ){
        do{

            n = QRandomGenerator::global()->bounded( 1, 5 );

            //QTime time = QTime::currentTime();
            //qsrand((uint)time.msec());
            //n = qrand() % 5;

        } while( checkrep( n, num ) );
        num[i] = n;
    }

    for( int i = 0; i < 4; i++ ) {
        num[i] = num[i] - 1;

        if ( lista.at( num[i] ) == listAnswers.at( numPreguntas ) )
            posCorrecta = i;
    }

    QString ca = listQuestions.at( numPreguntas );
    ui->textEditQuestion->setText( ca );

    ca = lista.at( num[0] );
    ui->textEditA->setText( ca );

    ca = lista.at( num[1] );
    ui->textEditB->setText( ca );

    ca = lista.at( num[2] );
    ui->textEditC->setText( ca );

    ca = lista.at( num[3] );
    ui->textEditD->setText( ca );

    if ( voice == "true" )
        speech->say( listQuestions.at(numPreguntas) );

    ui->pushButtonNext->setText( tr( "Comprobar" ) );
    ui->radioButtonA->setEnabled( true );
    ui->radioButtonB->setEnabled( true );
    ui->radioButtonC->setEnabled( true );
    ui->radioButtonD->setEnabled( true );
}

void DialogExam::on_pushButtonNext_clicked()
{
    if( ui->pushButtonNext->text() == tr( "Siguiente") ) {

        if( numPreguntas < rowCount ) {
            query->next();
            funShowFicha();
        } else {
            QMessageBox::information(this, QCoreApplication::applicationName(), tr("Hemos llegado al final"));
            close();
        }

    } else {

        if ( ui->radioButtonA->isChecked() )
            posRespuestaUsuario = 0;
        else if ( ui->radioButtonB->isChecked() )
            posRespuestaUsuario = 1;
        else if ( ui->radioButtonC->isChecked() )
            posRespuestaUsuario = 2;
        else if ( ui->radioButtonD->isChecked() )
            posRespuestaUsuario = 3;

        funCheck();

    }
}
