<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="Hello_en_GB">
<context>
    <name>DialogEditTest</name>
    <message>
        <location filename="dialogedittest.ui" line="14"/>
        <source>Test</source>
        <translation>Test</translation>
    </message>
    <message>
        <location filename="dialogedittest.ui" line="70"/>
        <source>Copiar Selección</source>
        <translation>Copy Selection</translation>
    </message>
    <message>
        <location filename="dialogedittest.ui" line="102"/>
        <source>Añadir Fila</source>
        <translation>Add Row</translation>
    </message>
    <message>
        <location filename="dialogedittest.ui" line="124"/>
        <source>Eliminar Fila</source>
        <translation>Delete Row</translation>
    </message>
    <message>
        <location filename="dialogedittest.ui" line="159"/>
        <source>Guardar y salir</source>
        <translation>Save and exit</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="66"/>
        <source>Error en la conexión con la base de datos</source>
        <translation>Failed to connect to the database</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="124"/>
        <source>Debe de seleccionar la fila a eliminar</source>
        <translation>You must select the row to delete</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="130"/>
        <source>¿Eliminar fila seleccionada?</source>
        <translation>Delete selected row?</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="148"/>
        <source>No se puede eliminar la fila seleccionada. Debe de haber al menos una</source>
        <translation>Cannot delete selected row. There must be at least one</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="184"/>
        <source>No hay celdas seleccionadas para copiar</source>
        <translation>No cells selected to copy</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="192"/>
        <source>Abrir archivo de texto para copiar</source>
        <translation>Open text file to copy</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="194"/>
        <source>Text (*.txt)</source>
        <translation>Text (*.txt)</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="198"/>
        <source>Error al abrir el archivo</source>
        <translation>Error opening file</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="202"/>
        <source>El proceso de importación ha comenzado.
Dependiendo del tamaño del archivo, el tiempo resultante variará</source>
        <translation>The import process has started.
        Depending on the size of the file, the resulting time will vary</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="242"/>
        <source>La importación del archivo de texto ha concluido</source>
        <translation>The import of the text file is complete</translation>
    </message>
</context>
<context>
    <name>DialogExam</name>
    <message>
        <location filename="dialogexam.ui" line="17"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogexam.ui" line="32"/>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogexam.ui" line="50"/>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogexam.ui" line="68"/>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogexam.ui" line="86"/>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogexam.ui" line="135"/>
        <location filename="dialogexam.cpp" line="115"/>
        <location filename="dialogexam.cpp" line="120"/>
        <location filename="dialogexam.cpp" line="284"/>
        <source>Siguiente</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="dialogexam.cpp" line="60"/>
        <source>Error en la conexión con la base de datos</source>
        <translation>Failed to connect to the database</translation>
    </message>
    <message>
        <location filename="dialogexam.cpp" line="275"/>
        <source>Comprobar</source>
        <translation>Check</translation>
    </message>
    <message>
        <location filename="dialogexam.cpp" line="290"/>
        <source>Hemos llegado al final</source>
        <translation>We have reached the end</translation>
    </message>
</context>
<context>
    <name>DialogFlashCards</name>
    <message>
        <location filename="dialogflashcards.ui" line="29"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogflashcards.ui" line="76"/>
        <source>La sabía</source>
        <translation>I knew it</translation>
    </message>
    <message>
        <location filename="dialogflashcards.ui" line="101"/>
        <location filename="dialogflashcards.cpp" line="64"/>
        <location filename="dialogflashcards.cpp" line="78"/>
        <location filename="dialogflashcards.cpp" line="106"/>
        <location filename="dialogflashcards.cpp" line="121"/>
        <source>Cara</source>
        <translation>Front</translation>
    </message>
    <message>
        <location filename="dialogflashcards.ui" line="111"/>
        <source>No la sabía</source>
        <translation>I did not know</translation>
    </message>
    <message>
        <location filename="dialogflashcards.cpp" line="49"/>
        <source>Error en la conexión con la base de datos</source>
        <translation>Failed to connect to the database</translation>
    </message>
    <message>
        <location filename="dialogflashcards.cpp" line="81"/>
        <source>Hemos llegado al final</source>
        <translation>We have reached the end</translation>
    </message>
    <message>
        <location filename="dialogflashcards.cpp" line="108"/>
        <source>Reverso</source>
        <translation>Back</translation>
    </message>
</context>
<context>
    <name>DialogOptions</name>
    <message>
        <location filename="dialogoptions.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogoptions.ui" line="28"/>
        <source>Fuente:</source>
        <translation>Font</translation>
    </message>
    <message>
        <location filename="dialogoptions.ui" line="68"/>
        <source>Tamaño fuente:</source>
        <translation>Font size</translation>
    </message>
    <message>
        <location filename="dialogoptions.ui" line="115"/>
        <source>Voz en Inglés</source>
        <translation>Voice in English</translation>
    </message>
    <message>
        <location filename="dialogoptions.ui" line="164"/>
        <source>Aceptar</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="dialogoptions.ui" line="186"/>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="29"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="57"/>
        <source>FlashCards</source>
        <translation>FlashCards</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="88"/>
        <location filename="mainwindow.cpp" line="72"/>
        <location filename="mainwindow.cpp" line="162"/>
        <source>Examen</source>
        <translation>Exam</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="116"/>
        <source>Editar Test</source>
        <translation>Edit Test</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="144"/>
        <source>Nuevo Test</source>
        <translation>New Test</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="172"/>
        <source>Opciones</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="200"/>
        <source>Acerca de</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <source>Editar</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="94"/>
        <source>Introduzca el título:</source>
        <translation>Enter the title:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="101"/>
        <source>El título introducido ya existe. Introduzca otro.</source>
        <translation>48 / 5000
        Resultados de traducción
        The entered title already exists. Enter another</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="107"/>
        <location filename="mainwindow.cpp" line="173"/>
        <source>Error en la conexión con la base de datos</source>
        <translation>Failed to connect to the database</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="184"/>
        <source>El Test debe de tener al menos 7 preguntas</source>
        <translation>The test must have at least 7 questions</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="dialogedittest.cpp" line="79"/>
        <source>Índice</source>
        <translation>Index</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="80"/>
        <source>Inglés</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="81"/>
        <source>Español</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <location filename="dialogedittest.cpp" line="82"/>
        <source>Cajas</source>
        <translation>Boxes</translation>
    </message>
</context>
</TS>
