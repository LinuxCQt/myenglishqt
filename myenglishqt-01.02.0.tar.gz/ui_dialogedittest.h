/********************************************************************************
** Form generated from reading UI file 'dialogedittest.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEDITTEST_H
#define UI_DIALOGEDITTEST_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_DialogEditTest
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QTableView *tableView;
    QFrame *frame;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButtonCopy;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButtonAddRow;
    QPushButton *pushButtonRemoveRow;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *pushButtonSaveAndExit;

    void setupUi(QDialog *DialogEditTest)
    {
        if (DialogEditTest->objectName().isEmpty())
            DialogEditTest->setObjectName(QString::fromUtf8("DialogEditTest"));
        DialogEditTest->resize(1159, 672);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/MyEnglishQt.ico"), QSize(), QIcon::Normal, QIcon::Off);
        DialogEditTest->setWindowIcon(icon);
        DialogEditTest->setModal(true);
        gridLayout = new QGridLayout(DialogEditTest);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        tableView = new QTableView(DialogEditTest);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        QFont font;
        font.setPointSize(14);
        tableView->setFont(font);
        tableView->setEditTriggers(QAbstractItemView::AnyKeyPressed|QAbstractItemView::DoubleClicked|QAbstractItemView::EditKeyPressed|QAbstractItemView::SelectedClicked);

        horizontalLayout->addWidget(tableView);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        frame = new QFrame(DialogEditTest);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(0, 40));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButtonCopy = new QPushButton(frame);
        pushButtonCopy->setObjectName(QString::fromUtf8("pushButtonCopy"));
        pushButtonCopy->setMinimumSize(QSize(0, 0));
        pushButtonCopy->setMaximumSize(QSize(16777215, 16777215));

        horizontalLayout_2->addWidget(pushButtonCopy);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        pushButtonAddRow = new QPushButton(frame);
        pushButtonAddRow->setObjectName(QString::fromUtf8("pushButtonAddRow"));
        pushButtonAddRow->setMinimumSize(QSize(0, 0));
        pushButtonAddRow->setMaximumSize(QSize(16777215, 16777215));
        pushButtonAddRow->setAutoDefault(false);

        horizontalLayout_2->addWidget(pushButtonAddRow);

        pushButtonRemoveRow = new QPushButton(frame);
        pushButtonRemoveRow->setObjectName(QString::fromUtf8("pushButtonRemoveRow"));
        pushButtonRemoveRow->setMinimumSize(QSize(0, 0));
        pushButtonRemoveRow->setMaximumSize(QSize(16777215, 16777215));
        pushButtonRemoveRow->setAutoDefault(false);

        horizontalLayout_2->addWidget(pushButtonRemoveRow);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        pushButtonSaveAndExit = new QPushButton(frame);
        pushButtonSaveAndExit->setObjectName(QString::fromUtf8("pushButtonSaveAndExit"));
        pushButtonSaveAndExit->setMinimumSize(QSize(0, 0));
        pushButtonSaveAndExit->setMaximumSize(QSize(16777215, 16777215));
        pushButtonSaveAndExit->setAutoDefault(false);

        horizontalLayout_2->addWidget(pushButtonSaveAndExit);


        gridLayout->addWidget(frame, 1, 0, 1, 1);

        QWidget::setTabOrder(tableView, pushButtonCopy);
        QWidget::setTabOrder(pushButtonCopy, pushButtonAddRow);
        QWidget::setTabOrder(pushButtonAddRow, pushButtonRemoveRow);
        QWidget::setTabOrder(pushButtonRemoveRow, pushButtonSaveAndExit);

        retranslateUi(DialogEditTest);

        QMetaObject::connectSlotsByName(DialogEditTest);
    } // setupUi

    void retranslateUi(QDialog *DialogEditTest)
    {
        DialogEditTest->setWindowTitle(QCoreApplication::translate("DialogEditTest", "Test", nullptr));
        pushButtonCopy->setText(QCoreApplication::translate("DialogEditTest", "Copiar Selecci\303\263n", nullptr));
        pushButtonAddRow->setText(QCoreApplication::translate("DialogEditTest", "A\303\261adir Fila", nullptr));
        pushButtonRemoveRow->setText(QCoreApplication::translate("DialogEditTest", "Eliminar Fila", nullptr));
        pushButtonSaveAndExit->setText(QCoreApplication::translate("DialogEditTest", "Guardar y salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogEditTest: public Ui_DialogEditTest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEDITTEST_H
