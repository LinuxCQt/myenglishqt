/********************************************************************************
** Form generated from reading UI file 'dialogexam.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEXAM_H
#define UI_DIALOGEXAM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_DialogExam
{
public:
    QVBoxLayout *verticalLayout_2;
    QTextEdit *textEditQuestion;
    QHBoxLayout *horizontalLayout;
    QRadioButton *radioButtonA;
    QTextEdit *textEditA;
    QHBoxLayout *horizontalLayout_4;
    QRadioButton *radioButtonB;
    QTextEdit *textEditB;
    QHBoxLayout *horizontalLayout_5;
    QRadioButton *radioButtonC;
    QTextEdit *textEditC;
    QHBoxLayout *horizontalLayout_6;
    QRadioButton *radioButtonD;
    QTextEdit *textEditD;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonNext;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QDialog *DialogExam)
    {
        if (DialogExam->objectName().isEmpty())
            DialogExam->setObjectName(QString::fromUtf8("DialogExam"));
        DialogExam->setWindowModality(Qt::WindowModal);
        DialogExam->resize(1017, 610);
        verticalLayout_2 = new QVBoxLayout(DialogExam);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        textEditQuestion = new QTextEdit(DialogExam);
        textEditQuestion->setObjectName(QString::fromUtf8("textEditQuestion"));
        textEditQuestion->setReadOnly(true);

        verticalLayout_2->addWidget(textEditQuestion);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        radioButtonA = new QRadioButton(DialogExam);
        radioButtonA->setObjectName(QString::fromUtf8("radioButtonA"));

        horizontalLayout->addWidget(radioButtonA);

        textEditA = new QTextEdit(DialogExam);
        textEditA->setObjectName(QString::fromUtf8("textEditA"));
        textEditA->setReadOnly(true);

        horizontalLayout->addWidget(textEditA);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        radioButtonB = new QRadioButton(DialogExam);
        radioButtonB->setObjectName(QString::fromUtf8("radioButtonB"));

        horizontalLayout_4->addWidget(radioButtonB);

        textEditB = new QTextEdit(DialogExam);
        textEditB->setObjectName(QString::fromUtf8("textEditB"));
        textEditB->setReadOnly(true);

        horizontalLayout_4->addWidget(textEditB);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        radioButtonC = new QRadioButton(DialogExam);
        radioButtonC->setObjectName(QString::fromUtf8("radioButtonC"));

        horizontalLayout_5->addWidget(radioButtonC);

        textEditC = new QTextEdit(DialogExam);
        textEditC->setObjectName(QString::fromUtf8("textEditC"));
        textEditC->setReadOnly(true);

        horizontalLayout_5->addWidget(textEditC);


        verticalLayout_2->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        radioButtonD = new QRadioButton(DialogExam);
        radioButtonD->setObjectName(QString::fromUtf8("radioButtonD"));

        horizontalLayout_6->addWidget(radioButtonD);

        textEditD = new QTextEdit(DialogExam);
        textEditD->setObjectName(QString::fromUtf8("textEditD"));
        textEditD->setReadOnly(true);

        horizontalLayout_6->addWidget(textEditD);


        verticalLayout_2->addLayout(horizontalLayout_6);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButtonNext = new QPushButton(DialogExam);
        pushButtonNext->setObjectName(QString::fromUtf8("pushButtonNext"));
        pushButtonNext->setMinimumSize(QSize(0, 0));
        pushButtonNext->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font.setPointSize(8);
        pushButtonNext->setFont(font);

        horizontalLayout_2->addWidget(pushButtonNext);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);

        QWidget::setTabOrder(radioButtonA, radioButtonB);
        QWidget::setTabOrder(radioButtonB, radioButtonC);
        QWidget::setTabOrder(radioButtonC, radioButtonD);
        QWidget::setTabOrder(radioButtonD, pushButtonNext);
        QWidget::setTabOrder(pushButtonNext, textEditQuestion);
        QWidget::setTabOrder(textEditQuestion, textEditA);
        QWidget::setTabOrder(textEditA, textEditB);
        QWidget::setTabOrder(textEditB, textEditC);
        QWidget::setTabOrder(textEditC, textEditD);

        retranslateUi(DialogExam);

        pushButtonNext->setDefault(false);


        QMetaObject::connectSlotsByName(DialogExam);
    } // setupUi

    void retranslateUi(QDialog *DialogExam)
    {
        DialogExam->setWindowTitle(QCoreApplication::translate("DialogExam", "Dialog", nullptr));
        radioButtonA->setText(QCoreApplication::translate("DialogExam", "A", nullptr));
        radioButtonB->setText(QCoreApplication::translate("DialogExam", "B", nullptr));
        radioButtonC->setText(QCoreApplication::translate("DialogExam", "C", nullptr));
        radioButtonD->setText(QCoreApplication::translate("DialogExam", "D", nullptr));
        pushButtonNext->setText(QCoreApplication::translate("DialogExam", "Siguiente", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogExam: public Ui_DialogExam {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEXAM_H
