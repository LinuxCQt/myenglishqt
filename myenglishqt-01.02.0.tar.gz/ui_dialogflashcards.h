/********************************************************************************
** Form generated from reading UI file 'dialogflashcards.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGFLASHCARDS_H
#define UI_DIALOGFLASHCARDS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_DialogFlashCards
{
public:
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QGroupBox *groupBox;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButtonIKnow;
    QPushButton *pushButtonFrontBack;
    QPushButton *pushButtonIDoNotKnow;
    QSpacerItem *horizontalSpacer_3;

    void setupUi(QDialog *DialogFlashCards)
    {
        if (DialogFlashCards->objectName().isEmpty())
            DialogFlashCards->setObjectName(QString::fromUtf8("DialogFlashCards"));
        DialogFlashCards->setWindowModality(Qt::WindowModal);
        DialogFlashCards->resize(1237, 640);
        DialogFlashCards->setMinimumSize(QSize(0, 0));
        DialogFlashCards->setMaximumSize(QSize(16777215, 16777215));
        DialogFlashCards->setModal(true);
        verticalLayout = new QVBoxLayout(DialogFlashCards);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit = new QTextEdit(DialogFlashCards);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);

        groupBox = new QGroupBox(DialogFlashCards);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(0, 0));
        groupBox->setMaximumSize(QSize(16777215, 16777215));
        horizontalLayout_2 = new QHBoxLayout(groupBox);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        pushButtonIKnow = new QPushButton(groupBox);
        pushButtonIKnow->setObjectName(QString::fromUtf8("pushButtonIKnow"));

        horizontalLayout_2->addWidget(pushButtonIKnow);

        pushButtonFrontBack = new QPushButton(groupBox);
        pushButtonFrontBack->setObjectName(QString::fromUtf8("pushButtonFrontBack"));
        pushButtonFrontBack->setMinimumSize(QSize(0, 0));
        pushButtonFrontBack->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font.setPointSize(8);
        pushButtonFrontBack->setFont(font);

        horizontalLayout_2->addWidget(pushButtonFrontBack);

        pushButtonIDoNotKnow = new QPushButton(groupBox);
        pushButtonIDoNotKnow->setObjectName(QString::fromUtf8("pushButtonIDoNotKnow"));

        horizontalLayout_2->addWidget(pushButtonIDoNotKnow);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);


        verticalLayout->addWidget(groupBox);

        QWidget::setTabOrder(pushButtonFrontBack, pushButtonIDoNotKnow);
        QWidget::setTabOrder(pushButtonIDoNotKnow, pushButtonIKnow);
        QWidget::setTabOrder(pushButtonIKnow, textEdit);

        retranslateUi(DialogFlashCards);

        pushButtonFrontBack->setDefault(true);


        QMetaObject::connectSlotsByName(DialogFlashCards);
    } // setupUi

    void retranslateUi(QDialog *DialogFlashCards)
    {
        DialogFlashCards->setWindowTitle(QCoreApplication::translate("DialogFlashCards", "Dialog", nullptr));
        groupBox->setTitle(QString());
        pushButtonIKnow->setText(QCoreApplication::translate("DialogFlashCards", "La sab\303\255a", nullptr));
        pushButtonFrontBack->setText(QCoreApplication::translate("DialogFlashCards", "Cara", nullptr));
        pushButtonIDoNotKnow->setText(QCoreApplication::translate("DialogFlashCards", "No la sab\303\255a", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogFlashCards: public Ui_DialogFlashCards {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGFLASHCARDS_H
