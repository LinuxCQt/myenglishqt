/*
  MyEnglishQt Copyright © 2020 Juan Ramón Goti Cid

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DIALOGFLASHCARDS_H
#define DIALOGFLASHCARDS_H

#include <QDialog>
#include <QTextToSpeech>
#include <QSqlDatabase>
#include <QSqlQuery>

namespace Ui {
class DialogFlashCards;
}

class DialogFlashCards : public QDialog
{
    Q_OBJECT

     QString nameTest;
     QString font;
     QString fontSize;
     QString voice;

     void closeEvent (QCloseEvent *event);

public:
    explicit DialogFlashCards( QString a_nameTest, QString my_font, QString my_fontSize, QString my_voice, QWidget *parent = 0 );
    ~DialogFlashCards();

private slots:
    void on_pushButtonFrontBack_clicked();
    void on_pushButtonIDoNotKnow_clicked();
    void on_pushButtonIKnow_clicked();

private:
    QSqlDatabase base;
    QSqlQuery *query;

    QTextToSpeech *speech;

    void funCenterText( QString cadena );
    void funNext();
    void funGuardarResultadoEnCajas( bool respuesta );

    Ui::DialogFlashCards *ui;
};

#endif // DIALOGFLASHCARDS_H
