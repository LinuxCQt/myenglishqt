/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButtonFlashCards;
    QPushButton *pushButtonExam;
    QPushButton *pushButtonEdit;
    QPushButton *pushButtonNew;
    QPushButton *pushButtonOptions;
    QPushButton *pushButtonAbout;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setWindowModality(Qt::ApplicationModal);
        MainWindow->resize(270, 74);
        MainWindow->setMinimumSize(QSize(0, 0));
        MainWindow->setMaximumSize(QSize(16777215, 16777215));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        pushButtonFlashCards = new QPushButton(centralWidget);
        pushButtonFlashCards->setObjectName(QString::fromUtf8("pushButtonFlashCards"));
        pushButtonFlashCards->setMinimumSize(QSize(0, 0));
        pushButtonFlashCards->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setFamily(QString::fromUtf8("DejaVu Sans"));
        font.setPointSize(10);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        pushButtonFlashCards->setFont(font);

        gridLayout->addWidget(pushButtonFlashCards, 1, 0, 1, 1);

        pushButtonExam = new QPushButton(centralWidget);
        pushButtonExam->setObjectName(QString::fromUtf8("pushButtonExam"));
        pushButtonExam->setMinimumSize(QSize(0, 0));
        pushButtonExam->setMaximumSize(QSize(16777215, 16777215));
        pushButtonExam->setFont(font);

        gridLayout->addWidget(pushButtonExam, 0, 0, 1, 1);

        pushButtonEdit = new QPushButton(centralWidget);
        pushButtonEdit->setObjectName(QString::fromUtf8("pushButtonEdit"));
        pushButtonEdit->setMinimumSize(QSize(0, 0));
        pushButtonEdit->setMaximumSize(QSize(16777215, 16777215));
        pushButtonEdit->setFont(font);

        gridLayout->addWidget(pushButtonEdit, 1, 1, 1, 1);

        pushButtonNew = new QPushButton(centralWidget);
        pushButtonNew->setObjectName(QString::fromUtf8("pushButtonNew"));
        pushButtonNew->setMinimumSize(QSize(0, 0));
        pushButtonNew->setMaximumSize(QSize(16777215, 16777215));
        pushButtonNew->setFont(font);

        gridLayout->addWidget(pushButtonNew, 0, 1, 1, 1);

        pushButtonOptions = new QPushButton(centralWidget);
        pushButtonOptions->setObjectName(QString::fromUtf8("pushButtonOptions"));
        pushButtonOptions->setMinimumSize(QSize(0, 0));
        pushButtonOptions->setMaximumSize(QSize(16777215, 16777215));
        pushButtonOptions->setFont(font);

        gridLayout->addWidget(pushButtonOptions, 0, 2, 1, 1);

        pushButtonAbout = new QPushButton(centralWidget);
        pushButtonAbout->setObjectName(QString::fromUtf8("pushButtonAbout"));
        pushButtonAbout->setMinimumSize(QSize(0, 0));
        pushButtonAbout->setMaximumSize(QSize(16777215, 16777215));
        pushButtonAbout->setFont(font);

        gridLayout->addWidget(pushButtonAbout, 1, 2, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        QWidget::setTabOrder(pushButtonExam, pushButtonFlashCards);
        QWidget::setTabOrder(pushButtonFlashCards, pushButtonNew);
        QWidget::setTabOrder(pushButtonNew, pushButtonEdit);
        QWidget::setTabOrder(pushButtonEdit, pushButtonOptions);
        QWidget::setTabOrder(pushButtonOptions, pushButtonAbout);

        retranslateUi(MainWindow);

        pushButtonFlashCards->setDefault(true);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButtonFlashCards->setText(QCoreApplication::translate("MainWindow", "FlashCards", nullptr));
        pushButtonExam->setText(QCoreApplication::translate("MainWindow", "Examen", nullptr));
        pushButtonEdit->setText(QCoreApplication::translate("MainWindow", "Editar Test", nullptr));
        pushButtonNew->setText(QCoreApplication::translate("MainWindow", "Nuevo Test", nullptr));
        pushButtonOptions->setText(QCoreApplication::translate("MainWindow", "Opciones", nullptr));
        pushButtonAbout->setText(QCoreApplication::translate("MainWindow", "Acerca de", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
