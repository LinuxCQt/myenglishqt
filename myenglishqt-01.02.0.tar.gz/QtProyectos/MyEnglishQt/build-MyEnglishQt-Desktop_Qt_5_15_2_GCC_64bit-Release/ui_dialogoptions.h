/********************************************************************************
** Form generated from reading UI file 'dialogoptions.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGOPTIONS_H
#define UI_DIALOGOPTIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_DialogOptions
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelFont;
    QFontComboBox *fontComboBoxFont;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelFontSize;
    QComboBox *comboBoxFontSize;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_4;
    QCheckBox *checkBoxVoice;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonOk;
    QPushButton *pushButtonCancel;

    void setupUi(QDialog *DialogOptions)
    {
        if (DialogOptions->objectName().isEmpty())
            DialogOptions->setObjectName(QString::fromUtf8("DialogOptions"));
        DialogOptions->resize(479, 145);
        verticalLayout = new QVBoxLayout(DialogOptions);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        labelFont = new QLabel(DialogOptions);
        labelFont->setObjectName(QString::fromUtf8("labelFont"));
        QFont font;
        font.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font.setPointSize(8);
        labelFont->setFont(font);

        horizontalLayout_2->addWidget(labelFont);

        fontComboBoxFont = new QFontComboBox(DialogOptions);
        fontComboBoxFont->setObjectName(QString::fromUtf8("fontComboBoxFont"));
        fontComboBoxFont->setFont(font);

        horizontalLayout_2->addWidget(fontComboBoxFont);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        labelFontSize = new QLabel(DialogOptions);
        labelFontSize->setObjectName(QString::fromUtf8("labelFontSize"));
        labelFontSize->setFont(font);

        horizontalLayout_3->addWidget(labelFontSize);

        comboBoxFontSize = new QComboBox(DialogOptions);
        comboBoxFontSize->setObjectName(QString::fromUtf8("comboBoxFontSize"));
        comboBoxFontSize->setFont(font);

        horizontalLayout_3->addWidget(comboBoxFontSize);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);

        checkBoxVoice = new QCheckBox(DialogOptions);
        checkBoxVoice->setObjectName(QString::fromUtf8("checkBoxVoice"));

        horizontalLayout_4->addWidget(checkBoxVoice);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButtonOk = new QPushButton(DialogOptions);
        pushButtonOk->setObjectName(QString::fromUtf8("pushButtonOk"));
        pushButtonOk->setMinimumSize(QSize(0, 0));
        pushButtonOk->setFont(font);

        horizontalLayout->addWidget(pushButtonOk);

        pushButtonCancel = new QPushButton(DialogOptions);
        pushButtonCancel->setObjectName(QString::fromUtf8("pushButtonCancel"));
        pushButtonCancel->setMinimumSize(QSize(0, 0));
        pushButtonCancel->setFont(font);

        horizontalLayout->addWidget(pushButtonCancel);


        verticalLayout->addLayout(horizontalLayout);

        QWidget::setTabOrder(fontComboBoxFont, comboBoxFontSize);
        QWidget::setTabOrder(comboBoxFontSize, checkBoxVoice);
        QWidget::setTabOrder(checkBoxVoice, pushButtonOk);
        QWidget::setTabOrder(pushButtonOk, pushButtonCancel);

        retranslateUi(DialogOptions);

        pushButtonOk->setDefault(true);


        QMetaObject::connectSlotsByName(DialogOptions);
    } // setupUi

    void retranslateUi(QDialog *DialogOptions)
    {
        DialogOptions->setWindowTitle(QCoreApplication::translate("DialogOptions", "Dialog", nullptr));
        labelFont->setText(QCoreApplication::translate("DialogOptions", "Fuente:", nullptr));
        labelFontSize->setText(QCoreApplication::translate("DialogOptions", "Tama\303\261o fuente:", nullptr));
        checkBoxVoice->setText(QCoreApplication::translate("DialogOptions", "Voz en Ingl\303\251s", nullptr));
        pushButtonOk->setText(QCoreApplication::translate("DialogOptions", "Aceptar", nullptr));
        pushButtonCancel->setText(QCoreApplication::translate("DialogOptions", "Cancelar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogOptions: public Ui_DialogOptions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGOPTIONS_H
